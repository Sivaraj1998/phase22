﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnADD_Click(object sender, RoutedEventArgs e)
        {
            AddCarDetails car = new AddCarDetails();
            car.Show();
            Close();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar car = new UpdateCar();
            car.Show();
            Close();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteCarDetail car = new DeleteCarDetail();
            car.Show();
            Close();

        }

        private void BtnGetAll_Click(object sender, RoutedEventArgs e)
        {
            GetAllCars car = new GetAllCars();
            car.Show();
            Close();
            
        }

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetcarBasedOnMN car = new GetcarBasedOnMN();
            car.Show();
            Close();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow car = new MainWindow();
            car.Show();
            Close();
        }
    }
}
