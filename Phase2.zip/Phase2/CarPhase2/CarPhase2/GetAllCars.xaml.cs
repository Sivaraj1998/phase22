﻿using Car_BAL;
using Car_Entity;
using Car_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for GetAllCars.xaml
    /// </summary>
    public partial class GetAllCars : Window
    {
        public GetAllCars()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetCars();
        }
        private void GetCars()   //displays service requests
        {
            try
            {
                CarBal bal = new CarBal();
                List<CarDetail> cars = bal.GetAllRequest();
                if (cars != null)
                {
                    dgCarDetails.ItemsSource = cars;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (CarException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

    }
}
