﻿using Car_BAL;
using Car_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for GetcarBasedOnMN.xaml
    /// </summary>
    public partial class GetcarBasedOnMN : Window
    {
        public GetcarBasedOnMN()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetMan();
            GetTypeId();
        }

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Getlist();
        }
        private void GetMan()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetManufacturerBL();
                cmbManufacturerId.ItemsSource = designationList.DefaultView;
                cmbManufacturerId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbManufacturerId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetCarTypeBL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Getlist()
        {

            try
            {
                int MName, Type;

                MName = cmbManufacturerId.SelectedIndex + 1;

                Type = cmbType.SelectedIndex + 1;

                dgCar.ItemsSource = CarBal.ShowBLL(MName, Type);
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Administrator administrator = new Administrator();
            administrator.Show();
            Close();
        }
    }
}
