﻿using Car_BAL;
using Car_Entity;
using Car_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for AddCarDetails.xaml
    /// </summary>
    public partial class AddCarDetails : Window
    {
        public AddCarDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetMan();
            GetTypeId();
            GetTrans();
        }

        private void BtnAddCar_Click(object sender, RoutedEventArgs e)
        {
            AddCar();
        }
        private void AddCar()
        {
            try
            {
                int manufacturerName;

                string model;

                int type;

                string engine;

                int bhp;

                int transmission;

                int mileage;

                int seats;

                string airbags;

                string bootSpace;

                string Price;

                //
                bool employeeAdded;
                //
                manufacturerName = Convert.ToInt32(cmbManufacturerId.SelectedValue);
                model = txtModel.Text;
                type = Convert.ToInt32(cmbType.SelectedValue);
                engine = txtEngine.Text;
                bhp = Convert.ToInt32(txtBHP.Text);
                transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                mileage = Convert.ToInt32(txtMileage.Text);
                seats = Convert.ToInt32(txtSeats.Text);
                airbags = txtAirbags.Text;
                bootSpace = (txtBootSpace.Text);
                Price = (txtPrice.Text);
                //
                CarDetail car = new CarDetail
                {
                    ManufacturerId = manufacturerName,
                    Model = model,
                    Type = type,
                    Engine = engine,
                    BHP = bhp,
                    Transmission = transmission,
                    Mileage = mileage,
                    Seats = seats,
                    Airbags = airbags,
                    BootSpace = bootSpace,
                    price = Price
                };
                CarBal carBal = new CarBal();
                employeeAdded = carBal.AddCar(car);
                if (employeeAdded == true)
                {
                    MessageBox.Show("Car Details added successfully. CarId:"+car.Id);
                }
                else
                {
                    MessageBox.Show("Car Details couldn't be added.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetMan()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetManufacturerBL();
                cmbManufacturerId.ItemsSource = designationList.DefaultView;
                cmbManufacturerId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbManufacturerId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetCarTypeBL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTrans()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetCarTransmissionBL();
                cmbTransmissionId.ItemsSource = designationList.DefaultView;
                cmbTransmissionId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransmissionId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnclose_Click(object sender, RoutedEventArgs e)
        {
            Administrator admin = new Administrator();
            admin.Show();
            this.Close();
        }
    }
}
