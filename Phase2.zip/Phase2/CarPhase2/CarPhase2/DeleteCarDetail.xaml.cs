﻿using Car_BAL;
using Car_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for DeleteCarDetail.xaml
    /// </summary>
    public partial class DeleteCarDetail : Window
    {
        public DeleteCarDetail()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDeleteCar_Click(object sender, RoutedEventArgs e)
        {
            DeleteCar();
        }
        private void DeleteCar()
        {
            try
            {
                string model;
                //
                bool CarDeleted;
                //
                model = txtId.Text;
                //
                CarBal bal = new CarBal();
                CarDeleted = bal.DeleteCarBL(model);
                if (CarDeleted == true)
                {
                    MessageBox.Show("Employee record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be deleted.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Administrator admin = new Administrator();
            admin.Show();
            Close();
        }
    }
}
