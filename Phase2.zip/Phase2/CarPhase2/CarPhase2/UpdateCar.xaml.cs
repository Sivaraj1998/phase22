﻿using Car_BAL;
using Car_Entity;
using Car_Exception;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarPhase2
{
    /// <summary>
    /// Interaction logic for UpdateCar.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetMan();
            GetTypeId();
            GetTrans();
        }

        private void BtnUpdateCar_Click(object sender, RoutedEventArgs e)
        {
            UpdateCars();
        }

        private void BtnSearchCar_Click(object sender, RoutedEventArgs e)
        {
            SearchCar();
        }
        private void SearchCar()
        {
            try
            {
                int id;
                //
                CarDetail objcar;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                CarBal carBal = new CarBal();
                objcar = carBal.SearchCarBL(id);
                if (objcar != null)
                {
                    cmbManufacturerId.SelectedValue = objcar.ManufacturerId;
                    txtModel.Text = objcar.Model;
                    txtMileage.Text = objcar.Mileage.ToString();
                    txtPrice.Text = objcar.price;
                    txtSeats.Text = objcar.Seats.ToString();
                    txtEngine.Text = objcar.Engine;
                    txtBootSpace.Text = objcar.BootSpace;
                    txtBHP.Text = objcar.BHP.ToString();
                    txtAirbags.Text = objcar.Airbags;
                    cmbTransmissionId.SelectedValue = objcar.Transmission;
                    cmbType.SelectedValue = objcar.Type;

                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateCars()
        {

            try
            {
                int id;
                int manufacturerName;

                string model;

                int type;

                string engine;

                int bhp;

                int transmission;

                int mileage;

                int seats;

                string airbags;

                string bootSpace;

                string Price;

                //
                bool carUpdated;
                //
                //
                id = Convert.ToInt32(txtId.Text);
                manufacturerName = Convert.ToInt32(cmbManufacturerId.SelectedValue);
                model = txtModel.Text;
                type = Convert.ToInt32(cmbType.SelectedValue);
                engine = txtEngine.Text;
                bhp = Convert.ToInt32(txtBHP.Text);
                transmission = Convert.ToInt32(cmbTransmissionId.SelectedValue);
                mileage = Convert.ToInt32(txtMileage.Text);
                seats = Convert.ToInt32(txtSeats.Text);
                airbags = txtAirbags.Text;
                bootSpace = (txtBootSpace.Text);
                Price = (txtPrice.Text);
                //
                CarDetail car = new CarDetail
                {
                    Id = id,
                    ManufacturerId = manufacturerName,
                    Model = model,
                    Type = type,
                    Engine = engine,
                    BHP = bhp,
                    Transmission = transmission,
                    Mileage = mileage,
                    Seats = seats,
                    Airbags = airbags,
                    BootSpace = bootSpace,
                    price = Price
                };
                CarBal carBal = new CarBal();
                carUpdated = carBal.UpdateCarBL(car);
                if (carUpdated == true)
                {
                    MessageBox.Show("Employee record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be updated.");
                }
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetMan()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetManufacturerBL();
                cmbManufacturerId.ItemsSource = designationList.DefaultView;
                cmbManufacturerId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbManufacturerId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTypeId()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetCarTypeBL();
                cmbType.ItemsSource = designationList.DefaultView;
                cmbType.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbType.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetTrans()
        {
            CarBal bal = new CarBal();
            try
            {
                DataTable designationList = bal.GetCarTransmissionBL();
                cmbTransmissionId.ItemsSource = designationList.DefaultView;
                cmbTransmissionId.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbTransmissionId.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (CarException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
