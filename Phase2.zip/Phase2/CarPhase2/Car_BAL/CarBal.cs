﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Car_DAL;
using Car_Entity;
using Car_Exception;

namespace Car_BAL
{
    public class CarBal
    {
        public static bool Validate(CarDetail car)
        {
            bool validate = true;
            try
            {
                if (!(Regex.IsMatch(car.Engine, @"^\d\.\dL$")))
                {
                    validate = false;
                    throw new CarException("Engine name should have 4 characters with 1st and 3rd character should be a number and 2nd should be a'.'and last would be a 'L'");

                }
                if (!(Regex.IsMatch(car.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("BHP should be a number");
                }
                if (!(Regex.IsMatch(car.Mileage.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Mileage should be a number");
                }
                if (!(Regex.IsMatch(car.Seats.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("seats should be a number");
                }
                if (!(Regex.IsMatch(car.Airbags, @"^[A-Za-z]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(car.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    validate = false;
                    throw new CarException("Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(car.price.ToString(), @"^[0-9]{1,}$")))
                {
                    validate = false;
                    throw new CarException("Price should be a number");
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
            return validate;

        }
        public  bool AddCar(CarDetail car)
        {
            bool CarAdded = false;
            try
            {
                if (Validate(car))
                {
                    CarDal carDal = new CarDal();
                    CarAdded = carDal.AddCarDetails(car);
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public  bool DeleteCarBL(string model)
        {
            bool carDeleted = false;
            try
            {
                if (model !=null)
                {
                    CarDal carDal = new CarDal();
                    carDeleted = carDal.DeleteCarDAL(model);
                }
                else
                {
                    throw new CarException("Employee Id must be greater than 0.");
                }
            }
            catch (CarException Cex)
            {
                throw Cex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }
        public  bool UpdateCarBL(CarDetail car)
        {
            bool carUpdated = false;
            try
            {
                if (Validate(car))
                {
                    CarDal carDal = new CarDal();
                    carUpdated = carDal.UpdateCarDAL(car);
                   
                }
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }
        public  CarDetail SearchCarBL(int carId)
        {
            CarDetail objCar = null;
            try
            {
                if (carId > 0)
                {
                    CarDal carDal = new CarDal();
                    objCar = carDal.SearchCarDAL(carId);
                }
                else
                {
                    throw new CarException("Employee Id must be greater than 0.");
                }
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objCar;
        }

        public  DataTable GetManufacturerBL()
        {
            DataTable ManufacturerList;
            try
            {
                CarDal carDAL = new CarDal();
                ManufacturerList = carDAL.GetManufacturer();
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ManufacturerList;
        }
        public DataTable GetCarTypeBL()
        {
            DataTable CarTypeList;
            try
            {
                CarDal carDAL = new CarDal();
                CarTypeList = carDAL.GetCarType(); ;
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTypeList;
        }
        public DataTable GetCarTransmissionBL()
        {
            DataTable CarTransmissionList;
            try
            {
                CarDal carDAL = new CarDal();
                CarTransmissionList = carDAL.GetCarTransmission(); 
            }
            catch (CarException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarTransmissionList;
        }
        public  List<CarDetail> GetAllRequest()
        {
            List<CarDetail> carList = null;
            try
            {
                CarDal DAL = new CarDal();
                carList = DAL.GetAllCarDetails();   //getallrequest in dal is accessed
            }
            catch (CarException Eex)
            {
                throw Eex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carList;
        }
        public static List<CarDetail> ShowBLL(int ManufacturerId, int TypeId)

        {

            List<CarDetail> cl = new List<CarDetail>();

            try

            {

                CarDal dal = new CarDal();

                cl = dal.ShowDAL(ManufacturerId, TypeId);

            }

            catch (CarException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return cl;

        }
    }
}
